<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('stylesAndJs.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

<div id="preloader"></div>
<div id="wrapper">
    <?php echo $__env->make('partials._nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('carousel'); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('stylesAndJs.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
