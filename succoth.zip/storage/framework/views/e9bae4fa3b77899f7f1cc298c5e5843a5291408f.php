

<?php $__env->startSection('title','| Home'); ?>

<?php $__env->startSection('carousel'); ?>
    <?php echo $__env->make('partials._carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="clearfix"></div>
    <div id="content" class="no-padding">
        <?php echo $__env->make('landing.sections.events', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('landing.sections.counter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('landing.sections.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('landing.sections.blogs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('landing.sections.sermons', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('landing.sections.testimonials', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>