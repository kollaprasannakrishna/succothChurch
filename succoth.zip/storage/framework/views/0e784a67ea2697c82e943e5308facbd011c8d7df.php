<!-- LOAD JS FILES -->
<?php echo Html::script('assets/js/jquery.min.js'); ?>

<?php echo Html::script('assets/js/bootstrap.min.js'); ?>

<?php echo Html::script('assets/js/jquery.isotope.min.js'); ?>

<?php echo Html::script('assets/js/jquery.prettyPhoto.js'); ?>

<?php echo Html::script('assets/js/easing.js'); ?>

<?php echo Html::script('assets/js/jquery.ui.totop.js'); ?>

<?php echo Html::script('assets/js/ender.js'); ?>

<?php echo Html::script('assets/js/responsiveslides.min.js'); ?>

<?php echo Html::script('assets/js/owl.carousel.js'); ?>

<?php echo Html::script('assets/js/jquery.fitvids.js'); ?>

<?php echo Html::script('assets/js/jquery.plugin.js'); ?>

<?php echo Html::script('assets/js/jquery.countdown.js'); ?>

<?php echo Html::script('assets/js/wow.min.js'); ?>

<?php echo Html::script('assets/js/custom.js'); ?>

<?php echo Html::script('assets/rs-plugin/js/jquery.themepunch.plugins.min.js'); ?>

<?php echo Html::script('assets/rs-plugin/js/jquery.themepunch.revolution.min.js'); ?>




















