<meta charset="utf-8">
<title>Blessing</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<!-- LOAD CSS FILES -->
{{--<link href="css/main.css" rel="stylesheet" type="text/css">--}}

{!! Html::style('assets/css/main.css') !!}