<!-- LOAD JS FILES -->
{!! Html::script('assets/js/jquery.min.js') !!}
{!! Html::script('assets/js/bootstrap.min.js') !!}
{!! Html::script('assets/js/jquery.isotope.min.js') !!}
{!! Html::script('assets/js/jquery.prettyPhoto.js') !!}
{!! Html::script('assets/js/easing.js') !!}
{!! Html::script('assets/js/jquery.ui.totop.js') !!}
{!! Html::script('assets/js/ender.js') !!}
{!! Html::script('assets/js/responsiveslides.min.js') !!}
{!! Html::script('assets/js/owl.carousel.js') !!}
{!! Html::script('assets/js/jquery.fitvids.js') !!}
{!! Html::script('assets/js/jquery.plugin.js') !!}
{!! Html::script('assets/js/jquery.countdown.js') !!}
{!! Html::script('assets/js/wow.min.js') !!}
{!! Html::script('assets/js/custom.js') !!}
{!! Html::script('assets/rs-plugin/js/jquery.themepunch.plugins.min.js') !!}
{!! Html::script('assets/rs-plugin/js/jquery.themepunch.revolution.min.js') !!}
{{--{!! Html::script('assets/js/rev-setting-1.js"') !!}--}}

{{--<script src="js/jquery.min.js"></script>--}}
{{--<script src="js/bootstrap.min.js"></script>--}}
{{--<script src="js/jquery.isotope.min.js"></script>--}}
{{--<script src="js/jquery.prettyPhoto.js"></script>--}}
{{--<script src="js/easing.js"></script>--}}
{{--<script src="js/jquery.ui.totop.js"></script>--}}
{{--<script src="js/ender.js"></script>--}}
{{--<script src="js/responsiveslides.min.js"></script>--}}
{{--<script src="js/owl.carousel.js"></script>--}}
{{--<script src="js/jquery.fitvids.js"></script>--}}
{{--<script src="js/jquery.plugin.js"></script>--}}
{{--<script src="js/jquery.countdown.js"></script>--}}
{{--<script src="js/countdown-custom.js"></script>--}}
{{--<script src="js/wow.min.js"></script>--}}
{{--<script src="js/custom.js"></script>--}}
{{--<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.plugins.min.js"></script>--}}
{{--<script type="text/javascript" src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>--}}
{{--<script src="js/rev-setting-1.js"></script>--}}