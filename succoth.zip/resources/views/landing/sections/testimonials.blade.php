<!-- section begin -->
<section id="section-testimonial">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div id="testi-carousel" class="testi-slider text-center wow fadeInUp">
                    <div class="item">
                        <img src="img/testi/pic%20(1).jpg" alt="" class="img-circle">
                        <blockquote>Blessing theme has a real desire and heart for ministry within the local church</blockquote>
                        <span class="testi-by">Aline Drummond</span>
                    </div>
                    <div class="item">
                        <img src="img/testi/pic%20(2).jpg" alt="" class="img-circle">
                        <blockquote>I Just wanted to let you know how pleased we are and how great the Blessing theme is working for our National Church </blockquote>
                        <span class="testi-by">Mortimer Elmo</span>
                    </div>
                    <div class="item">
                        <img src="img/testi/pic%20(3).jpg" alt="" class="img-circle">
                        <blockquote>
                            Get in touch with Blessing theme today and get ready to see your church grow!

                        </blockquote>
                        <span class="testi-by">Marina Leopold</span>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- section close -->