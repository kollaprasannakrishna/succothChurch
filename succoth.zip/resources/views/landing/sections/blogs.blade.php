<!-- section begin -->
<section id="page-blog" class="no-padding">

    <div class="fullwidth">
        <div class="one-fourth text-center">
            <div class="title-area wow slideInLeft">
                <span>Latest</span>
                <h1>Blog</h1>
            </div>
        </div>

        <div class="three-fourth">
            <div class="custom-carousel-2">
                <div class="item-blog">
                    <div class="inner">
                        <span class="date">10 November</span>
                        <a href="#">
                            <h3>Gods goal for you</h3>
                        </a>
                        <span class="desc">The Bible says, "Give thanks in everything"  consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </span>
                    </div>
                </div>

                <div class="item-blog even">
                    <div class="inner">
                        <span class="date">9 November</span>
                        <a href="#">
                            <h3>The Bible on Campus</h3>
                        </a>
                        <span class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </span>
                    </div>
                </div>

                <div class="item-blog">
                    <div class="inner">
                        <span class="date">8 November</span>
                        <a href="#">
                            <h3>A Faithful Witness</h3>
                        </a>
                        <span class="desc">Those who are prepared to witness and sensitive to opportunities the Lord opens up will find occasions on every hand to share Christ.
                                    </span>
                    </div>
                </div>

                <div class="item-blog even">
                    <div class="inner">
                        <span class="date">7 November</span>
                        <a href="#">
                            <h3>Transfoming Live</h3>
                        </a>
                        <span class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </span>
                    </div>
                </div>

                <div class="item-blog">
                    <div class="inner">
                        <span class="date">6 November</span>
                        <a href="#">
                            <h3>Restoring Hope</h3>
                        </a>
                        <span class="desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    </span>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</section>
<!-- section close -->