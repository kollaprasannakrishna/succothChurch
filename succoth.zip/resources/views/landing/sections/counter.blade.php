<!-- section begin -->
<section id="countdown-container" data-speed="5" data-type="background">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-6 wow fadeInLeft">
                <h3>Transforming Live, Restoring Hope</h3>
                <span class="time">April 10, 2017 8:00 pm</span>
            </div>

            <div class="col-md-6 wow fadeInRight" data-wow-delay=".25s">
                <div id="defaultCountdown"></div>
            </div>
        </div>
    </div>
</section>
<!-- section close -->